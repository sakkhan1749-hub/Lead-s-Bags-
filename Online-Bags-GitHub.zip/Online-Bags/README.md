# Online Bags

GitHub Pages website for Online Bags.

- Price: ₹750
- WhatsApp ordering: +91 9053850125
- Main file: `index.html`

## Photos
Put your product photos inside `images/` and name them:
- bag1.jpg
- bag2.jpg
- bag3.jpg
